// svec.h
// Author: Nat Tuck
// 3650F2017, Challenge01 Hints

#ifndef SVEC_H
#define SVEC_H

typedef struct svec {
    int size;
    int cap;
    char** data;
} svec;

svec* make_svec();
void  free_svec(svec* sv);

char* svec_get(svec* sv, int ii);
void  svec_put(svec* sv, int ii, char* item);

void svec_push_back(svec* sv, char* item);

void svec_sort(svec* sv);

// My function
void dyArray_print_with_interrupt(svec* sv);

#endif
